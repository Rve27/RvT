#!/system/bin/sh

MODDIR=${0%/*}

sleep 30
ok=0
while :
do
  service call SurfaceFlinger 1008 i32 1
  ok=$(service list | grep -c "SurfaceFlinger")
  if [ $ok -eq 1 ]; then
    break
  else
    sleep 5
  fi
done

sleep 5

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

# Sync before execute
sync

# Disable Core control / hotplug
for hotplug in /sys/devices/system/cpu/cpu[0,4,7]/core_ctl; do
    write $hotplug/enable 0
done

#gpu turbo boost v2
write /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor interactive
write /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor interactive
write /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor interactive
write /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor interactive
write /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor interactive
write /sys/devices/system/cpu/cpu5/cpufreq/scaling_governor interactive
write /sys/devices/system/cpu/cpu6/cpufreq/scaling_governor interactive
write /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor interactive
write /sys/devices/system/cpu/cpufreq/policy0/scaling_governor interactive
write /sys/devices/system/cpu/cpufreq/policy4/scaling_governor interactive
#policy0
write /sys/devices/system/cpu/cpufreq/policy0/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpufreq/policy0/interactive/boost 1
write /sys/devices/system/cpu/cpufreq/policy0/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpufreq/policy0/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpufreq/policy0/interactive/align_windows 1
#policy4
write /sys/devices/system/cpu/cpufreq/policy4/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpufreq/policy4/interactive/boost 1
write /sys/devices/system/cpu/cpufreq/policy4/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpufreq/policy4/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpufreq/policy4/interactive/align_windows 1
#cpu0
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/align_windows 1
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/align_windows 1
#1
write /sys/devices/system/cpu/cpu1/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu1/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu1/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu1/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu1/cpufreq/interactive/align_windows 1
write /sys/devices/system/cpu/cpu1/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu1/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu1/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu1/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu1/cpufreq/interactive/align_windows 1
#2
write /sys/devices/system/cpu/cpu2/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu2/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu2/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu2/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu2/cpufreq/interactive/align_windows 1
write /sys/devices/system/cpu/cpu2/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu2/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu2/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu2/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu2/cpufreq/interactive/align_windows 1
#3
write /sys/devices/system/cpu/cpu3/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu3/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu3/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu3/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu3/cpufreq/interactive/align_windows 1
write /sys/devices/system/cpu/cpu3/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu3/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu3/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu3/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu3/cpufreq/interactive/align_windows 1
#4
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/align_windows 1
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/align_windows 1
#5
write /sys/devices/system/cpu/cpu5/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu5/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu5/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu5/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu5/cpufreq/interactive/align_windows 1
write /sys/devices/system/cpu/cpu5/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu5/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu5/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu5/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu5/cpufreq/interactive/align_windows 1
#6
write /sys/devices/system/cpu/cpu6/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu6/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu6/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu6/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu6/cpufreq/interactive/align_windows 1
write /sys/devices/system/cpu/cpu6/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu6/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu6/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu6/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu6/cpufreq/interactive/align_windows
#7
write /sys/devices/system/cpu/cpu7/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu7/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu7/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu7/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu7/cpufreq/interactive/align_windows 1
write /sys/devices/system/cpu/cpu7/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu7/cpufreq/interactive/boost 1
write /sys/devices/system/cpu/cpu7/cpufreq/interactive/go_hispeed_load 75
write /sys/devices/system/cpu/cpu7/cpufreq/interactive/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpu7/cpufreq/interactive/align_windows 1

#gpu
write /sys/kernel/gpu/gpu_governor msm-adreno-tz

#cpuset
write /dev/cpuset/foreground/boost/cpus 4-7
write /dev/cpuset/foreground/cpus 0-3,4-7
write /dev/cpuset/top-app/cpus 0-7

#disable msm-thermal
write /sys/module/msm-thermal/parameters/enabled N

#disable adreno idler
write /sys/module/adreno_idler/parameters/adreno_idler_active N

#disable CRC
write /sys/module/mmc_core/parameters/use_spi_crc N

#memory virtual optimization v2
write /proc/sys/vm/vfs_cache_pressure 50
write /proc/sys/vm/oom_kill_allocating_task 0
write /proc/sys/vm/page-cluster 0
write /proc/sys/vm/extrafrag_threshold 750
write /proc/sys/vm//drop_caches 3
write /proc/sys/vm/swappiness 100
write /proc/sys/vm/stat_interval 8



#stop log
su -c "stop logd"
su -c "stop tcpdump"
su -c "stop cnss_diag"
su -c "stop statsd"
su -c "stop traced"
su -c "stop idd-logreader"
su -c "stop idd-logreadermain"
su -c "stop vendor.perfservice"
su -c "stop miuibooster"

#disable kernel panic
write /proc/sys/kernel/panic 0
write /proc/sys/kernel/panic_on_oops 0
write /proc/sys/kernel/panic_on_warn 0
write /proc/sys/kernel/panic_on_rcu_stall 0
write /sys/module/kernel/parameters/panic 0
write /sys/module/kernel/parameters/panic_on_warn 0
write /sys/module/kernel/parameters/pause_on_oops 0
write /sys/module/kernel/panic_on_rcu_stall 0

#disable fsync
write /sys/module/sync/parameters/fsync_enabled N

#disable printk
write /proc/sys/kernel/printk 0 0 0 0
write /proc/sys/kernel/printk_devkmsg off
write /sys/module/printk/parameters/console_suspend Y
write /sys/module/printk/parameters/cpu N
write /sys/kernel/printk_mode/printk_mode 0
write /sys/module/printk/parameters/ignore_loglevel Y
write /sys/module/printk/parameters/pid N
write /sys/module/printk/parameters/time N

#Delete Logs
rm -rf /data/anr/*
rm -rf /cache/*.apk
rm -rf /data/log_other_mode/*
rm -rf /cache/*.tmp
rm -rf /dev/log/*
rm -rf /data/tombstones/*
rm -rf /data/log_other_mode/*
rm -rf /data/system/dropbox/*
rm -rf /data/system/usagestats/*
rm -rf /data/log/*
rm -rf /sys/kernel/debug/*
rm -rf /data/local/tmp*
rm -rf /dev/log/main
rm -rf /data/system/package_cache
rm -rf /data/dalvik-cache
rm -rf /data/anr/*
rm -rf /data/media/0/DCIM/.thumbnails
rm -rf /data/media/0/Pictures/.thumbnails
rm -rf /data/media/0/Music/.thumbnails
rm -rf /data/media/0/Movies/.thumbnails
rm -rf /data/media/0/mtklog
rm -rf /data/media/0/MIUI/Gallery
rm -rf /data/media/0/MIUI/.debug_log
rm -rf /data/media/0/MIUI/BugReportCache
rm -rf /data/vendor/thermal/config
rm -rf /data/vendor/thermal/thermal.dump
rm -rf /data/vendor/thermal/last_thermal.dump
rm -rf /data/vendor/thermal/thermal_history.dump
rm -rf /data/vendor/thermal/thermal_history_last.dump

#Disabling Scheduler statistics
echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk0rpmb/queue/iostats
echo "0" > /sys/block/mmcblk1/queue/iostats
echo "0" > /sys/block/loop0/queue/iostats
echo "0" > /sys/block/loop1/queue/iostats
echo "0" > /sys/block/loop2/queue/iostats
echo "0" > /sys/block/loop3/queue/iostats
echo "0" > /sys/block/loop4/queue/iostats
echo "0" > /sys/block/loop5/queue/iostats
echo "0" > /sys/block/loop6/queue/iostats
echo "0" > /sys/block/loop7/queue/iostats
echo "0" > /sys/block/loop8/queue/iostats
echo "0" > /sys/block/loop9/queue/iostats
echo "0" > /sys/block/loop10/queue/iostats
echo "0" > /sys/block/loop11/queue/iostats
echo "0" > /sys/block/loop12/queue/iostats
echo "0" > /sys/block/loop13/queue/iostats
echo "0" > /sys/block/loop14/queue/iostats
echo "0" > /sys/block/loop15/queue/iostats
echo "0" > /sys/fs/f2fs_dev/mmcblk0p79/iostat_enable

#fstrim
su -c "fstrim -v /data"
su -c "fstrim -v /system"
su -c "fstrim -v /cache"
su -c "fstrim -v /vendor"
su -c "fstrim -v /product"

#exit
exit 0